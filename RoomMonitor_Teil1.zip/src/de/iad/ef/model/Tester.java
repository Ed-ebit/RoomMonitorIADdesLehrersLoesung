package de.iad.ef.model;

class TestSuiteApp {
      public static void main(String[] args) {

        BasicCounterTest testUmgebung = new BasicCounterTest();
        // Erster Test StandardKonstruktor
        //testStandardKonstruktor(testUmgebung);
        //testParameterKonstruktor(testUmgebung);
        //testSetUndReset(testUmgebung);
    }

}

class LimitedCounterTest{
    class Tester extends LimitedCounter{

    }
}
class BasicCounterTest {
    class Tester extends BasicCounter{

        public Tester(){
            super(); // Konstruktoraufruf ind der Basisklasse
        }
        public Tester(Integer initVal){
            super(initVal);
        }
        @Override
        public Integer currentCount() {
            return super.currentCount();
        }
        @Override
        public void reset() {
            super.reset();
        }
        @Override
        public void setCount(Integer count) {
            super.setCount(count);
        }
    }
    private static void testSetUndReset(BasicCounterTest testUmgebung) {
        Tester tester = testUmgebung.new Tester(42);
        System.out.println("Test Paramter Konstruktor erwartet 42 und geliefert wird 42 "+
                (tester.currentCount()==42 ? "ok":"fehler"));
        tester.setCount(4711);
        System.out.println("Set Count auf 4711 erwartet 4711 und geliefert wird 4711 "+
                (tester.currentCount()==4711 ? "ok":"fehler"));
        tester.reset();
        System.out.println("Test Reset erwartet 42 und geliefert wird 42 "+
                (tester.currentCount()==42 ? "ok":"fehler"));
    }

    private static void testParameterKonstruktor(BasicCounterTest testUmgebung) {
        Tester tester = testUmgebung.new Tester(4711);
        System.out.println("Test Paramter Konstruktor erwartet 4711 und geliefert wird 4711 "+
                (tester.currentCount()==4711 ? "ok":"fehler"));
    }

    private static void testStandardKonstruktor(BasicCounterTest testUmgebung) {
        Tester tester = testUmgebung.new Tester();
        System.out.println("Test Std Konstruktor erwartet 0 und geliefert wird 0 "+
                (tester.currentCount()==0 ? "ok":"fehler"));
    }
}
